# config file for bash-completion
# https://github.com/scop/bash-completion

set (BASH_COMPLETION_VERSION "2.12.0")

set (BASH_COMPLETION_PREFIX "/var/usr")

set (BASH_COMPLETION_COMPATDIR "/var/usr/etc/bash_completion.d")
set (BASH_COMPLETION_COMPLETIONSDIR "/var/usr/share/bash-completion/completions")
set (BASH_COMPLETION_HELPERSDIR "/var/usr/share/bash-completion/helpers")

set (BASH_COMPLETION_FOUND "TRUE")
